#define SI	1  
#define NO	0

int es_par (int);
int es_impar (int);
int es_primo (int);
int max_valor (int ,int , int );
int min_valor (int ,int , int );
void max_min_valor (int ,int , int , int*, int *);
