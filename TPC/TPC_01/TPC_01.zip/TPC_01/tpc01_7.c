#include "func.h"

void max_min_valor (int a,int b, int c, int*max, int *min)
{
		
	*min = min_valor(a,b,c);
	*max = max_valor(a,b,c); 
}
